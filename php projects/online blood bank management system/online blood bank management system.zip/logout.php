<?php
require_once 'php/DBConnect.php';

$db = new DBConnect();
$db->logout();
?>