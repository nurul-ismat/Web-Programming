<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
</head>

<body>
<!---banner--->
			<div id="section-1" class="section">
			    <div id="top" class="callbacks_container">
			      <ul class="rslides" id="slider4">
			        <li>
			          <img src="images/o-TRAVEL-facebook.jpg" alt="">
					  <div class="caption">
			     	  		<div class="header-info">
							<h2><a href="#">Your Trusted Travel Packages and Services</a></h2>
							<lable></lable>
							<h1><a href="#">Go Travel & Tourism Ltd </a></h1>
							</div>
			          </div>
			        
			    </div>	         
			    <div class="clearfix"> </div>
				</div>
<!---banner--->	
</body>
</html>